# Welcome to the Stripe Extension
### Getting Started

![Alt text](/metadata/1.png)

1. Head over to your Stripe Dashboard.
2. Navigate to Developers > API Keys.
3. For the stripeLiveApiKey preference variable, enter your live API key (Secret Key).
4. For the stripeTestApiKey preference variable, enable Test Mode and then copy over the test API Key (Secret Key).
5. Done! Enjoy easy access to your Stripe Dashboard!

Lots of love, Motis Group