export type GetProductOutput = {
	id: number;
	title: string;
};
