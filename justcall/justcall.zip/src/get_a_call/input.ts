export type GetProductInput = {
	id: number;
};
